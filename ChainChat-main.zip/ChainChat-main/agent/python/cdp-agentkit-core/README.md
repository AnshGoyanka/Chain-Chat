# Agentkit Core

Framework agnostic primitives that are meant to be composable and used via Agentkit framework extensions.

You can find all of the supported actions under `./cdp_agentkit_core/actions`.

## Contributing

See [CONTRIBUTING.md](../../CONTRIBUTING.md) for more information.

