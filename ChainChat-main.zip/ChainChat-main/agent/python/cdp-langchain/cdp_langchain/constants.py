"""Specifies package level constants used throughout the package."""

# CDP_LANGCHAIN_DEFAULT_SOURCE (str): Denotes the default source for CDP Langchain Agentkit extensions.
CDP_LANGCHAIN_DEFAULT_SOURCE = "cdp-langchain"
