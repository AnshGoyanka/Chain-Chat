/** @type {import('next').NextConfig} */
const nextConfig = {
    images: {
        domains: ["coin-images.coingecko.com", "s2.coinmarketcap.com"],
    },
};

export default nextConfig;
